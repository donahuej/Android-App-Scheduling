package com.example.staffingmanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.staffingmanager.database.EmployeeDao;
import com.example.staffingmanager.database.ProjectDao;

public class CreateEmployeeActivity extends AppCompatActivity {

    EmployeeDao employeeDao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_employee);

        employeeDao= employeeDao.getInstance(getApplicationContext());
        employeeDao.openDb();


    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        employeeDao.closeDB();
    }

    public void onSubmit(View view){

        EmployeeDao employeeDao = EmployeeDao.getInstance(getApplicationContext());
        EditText NameEditView =  (EditText)findViewById(R.id.employeeFirstName);
        String Name = NameEditView.getText().toString();

        EditText descEditView= (EditText)findViewById(R.id.employeeLastName);
        String desc = descEditView.getText().toString();

        EditText managerEditView= (EditText)findViewById(R.id.email);
        String manager = managerEditView.getText().toString();


        employeeDao.insertEmployee(new Employee(Name,desc,manager));
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        Toast.makeText(this, "Employee Created", Toast.LENGTH_LONG).show();

    }


}
