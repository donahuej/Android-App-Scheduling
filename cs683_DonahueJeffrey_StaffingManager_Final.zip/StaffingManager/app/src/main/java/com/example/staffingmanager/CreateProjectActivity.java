package com.example.staffingmanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.staffingmanager.database.ProjectDao;

public class CreateProjectActivity extends AppCompatActivity {

    ProjectDao ProjectDao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_project);

        ProjectDao = ProjectDao.getInstance(getApplicationContext());
        ProjectDao.openDb();


    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        ProjectDao.closeDB();
    }

    public void onSubmit(View view){

        ProjectDao projectDao = ProjectDao.getInstance(getApplicationContext());
        EditText NameEditView =  (EditText)findViewById(R.id.projectName);
        String Name = NameEditView.getText().toString();

        EditText descEditView= (EditText)findViewById(R.id.project_description);
        String desc = descEditView.getText().toString();

        EditText managerEditView= (EditText)findViewById(R.id.project_manager);
        String manager = managerEditView.getText().toString();


        projectDao.insertProject(new Project(Name,desc,manager));
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        Toast.makeText(this, "Project Created", Toast.LENGTH_LONG).show();

    }


}
