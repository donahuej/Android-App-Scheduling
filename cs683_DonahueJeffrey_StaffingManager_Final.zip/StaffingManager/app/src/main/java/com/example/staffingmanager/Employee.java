package com.example.staffingmanager;

public class Employee {
    private int id;
    private String FirstName;
    private String LastName;
    private String email;

    public Employee(String FirstName, String LastName, String email){
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.email = email;
    }

    public String getFirstName(){return FirstName;}

    public String getLastName(){return FirstName;}


    public String getName(){return FirstName + " " + LastName;}

    public String getEmail(){return email;}

}
