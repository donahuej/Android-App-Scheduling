package com.example.staffingmanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.staffingmanager.database.TimeDao;

import java.util.ArrayList;
import java.util.List;

public class EmployeeActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<RecordTime> cards;
    TimeDao timeDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_employee);



        timeDao = TimeDao.getInstance(getApplicationContext());
        timeDao.openDb();
        List<String> employees = timeDao.getAllEmployeeNames();



        Spinner spinner = findViewById(R.id.spinnerChooseEmp);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, employees);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);


    }

    public void employeeOnClick(View view){
        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Spinner spinner2 = findViewById(R.id.spinnerChooseEmp);
        String prompt = spinner2.getSelectedItem().toString();

        timeDao = TimeDao.getInstance(getApplicationContext());
        timeDao.openDb();
        cards = timeDao.getAllProjectbyEmployee(prompt);

        EmployeeAdapter employeeAdapter = new EmployeeAdapter(this, cards);

        recyclerView.setAdapter(employeeAdapter);

    }
}
