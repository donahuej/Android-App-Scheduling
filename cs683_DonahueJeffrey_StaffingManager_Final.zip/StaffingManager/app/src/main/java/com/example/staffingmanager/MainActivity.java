package com.example.staffingmanager;

import android.content.Intent;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    public void CreateTimeOnClick(View view){
        Intent intent = new Intent(this, TimeActivity.class);
        startActivity(intent);
        Log.i("Tag", "Create Schedule Called");
    }

    public void ViewEmpOnClick(View view){
        Intent intent = new Intent(this, EmployeeActivity.class);
        startActivity(intent);
        Log.i("Tag", "View Employee Called");
    }

    public void ViewProjOnClick(View view){
        Intent intent = new Intent(this, ProjectActivity.class);
        startActivity(intent);
        Log.i("Tag", "View Project Called");
    }

    public void CreateProjOnClick(View view){
        Intent intent = new Intent(this, CreateProjectActivity.class);
        startActivity(intent);
        Log.i("Tag", "Create Project Called");
    }

    public void EmployeeOnClick(View view){
        Intent intent = new Intent(this, CreateEmployeeActivity.class);
        startActivity(intent);
        Log.i("Tag", "Create Employee Called");
    }

    @Override
    public void onStart() {
        super.onStart();

    }

}
