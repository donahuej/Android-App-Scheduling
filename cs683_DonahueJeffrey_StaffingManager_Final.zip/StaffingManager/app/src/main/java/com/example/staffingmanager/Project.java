package com.example.staffingmanager;

public class Project {
    private int Projid;
    private String ProjectName;
    private String ProjectDesc;
    private String ProjectManager;

    public Project(String ProjectName, String ProjectDesc, String ProjectManager){
        this.Projid = Projid;
        this.ProjectName = ProjectName;
        this.ProjectDesc = ProjectDesc;
        this.ProjectManager = ProjectManager;
    }

    public String getProjName(){return ProjectName;}

    public String getProjDesc(){return ProjectDesc;}

    public String getProjManager(){return ProjectManager;}

    public int getProjid(){return Projid;}

}
