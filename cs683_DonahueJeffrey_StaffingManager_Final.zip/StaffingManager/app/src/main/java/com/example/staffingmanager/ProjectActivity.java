package com.example.staffingmanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.staffingmanager.database.ProjectDao;
import com.example.staffingmanager.database.TimeDao;

import java.util.ArrayList;
import java.util.List;

public class ProjectActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<RecordTime> cards;
    TimeDao timeDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_project);

        //recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        //recyclerView.setHasFixedSize(true);
        //recyclerView.setLayoutManager(new LinearLayoutManager(this));



        timeDao = TimeDao.getInstance(getApplicationContext());
        timeDao.openDb();
        //cards = timeDao.getAllProjectbyProject("Project 1");
        List<String> projects = timeDao.getAllProjectNames();



        Spinner spinner = findViewById(R.id.spinnerChoosePro);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, projects);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);

        //EmployeeAdapter employeeAdapter = new EmployeeAdapter(this, cards);

        //recyclerView.setAdapter(employeeAdapter);
    }

    public void buttonOnClick(View view){
        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Spinner spinner2 = findViewById(R.id.spinnerChoosePro);
        String prompt = spinner2.getSelectedItem().toString();

        timeDao = TimeDao.getInstance(getApplicationContext());
        timeDao.openDb();
        cards = timeDao.getAllProjectbyProject(prompt);

        EmployeeAdapter employeeAdapter = new EmployeeAdapter(this, cards);

        recyclerView.setAdapter(employeeAdapter);

    }


}
