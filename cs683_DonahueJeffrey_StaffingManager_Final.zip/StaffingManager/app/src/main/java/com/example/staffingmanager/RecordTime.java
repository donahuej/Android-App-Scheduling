package com.example.staffingmanager;

public class RecordTime {
    private String ProjName;
    private String EmpName;
    private String Date;
    private String Hours;
    private String Details;

    public RecordTime(String Projid, String Empid, String Date, String Hours, String Details){
        this.ProjName = Projid;
        this.EmpName = Empid;
        this.Date = Date;
        this.Hours = Hours;
        this.Details = Details;
    }

    public String getProjName(){return ProjName;}

    public String getEmployeeName(){return EmpName;}

    public String getDate(){return Date;}

    public String getHours(){return Hours;}

    public String getDetails(){return Details;}



}
