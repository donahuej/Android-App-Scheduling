package com.example.staffingmanager;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.staffingmanager.database.EmployeeDBContract;
import com.example.staffingmanager.database.EmployeeDao;
import com.example.staffingmanager.database.ProjectDao;
import com.example.staffingmanager.database.TimeDao;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class TimeActivity extends AppCompatActivity {

    Spinner spinner;
    Spinner proj;
    Spinner emp;
    TimeDao timeDao;
    EmployeeDao employeeDao;
    public SQLiteDatabase mReadableDB, mWritableDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_schedule);


        timeDao = TimeDao.getInstance(getApplicationContext());
        timeDao.openDb();
        List<String> employees = new ArrayList<>();
        employees.add("Jeff Donahue");
        employees.add("Mike Smith");
        employees.add("James White");
        employees.add("Forrest Gump");

        List<String> projects = new ArrayList<>();
        projects.add("App Development");
        projects.add("App QA");
        projects.add("Quarterly Analytics");
        projects.add("Holiday Party");
        projects.add("Board Report");

        Spinner spinner = findViewById(R.id.employee_spinner);
        Spinner spinner2 = findViewById(R.id.project_spinner);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, employees);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, projects);
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(arrayAdapter2);





    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        timeDao.closeDB();
    }

    public void timeOnClick(View view){

        TimeDao TimeDao3 = TimeDao.getInstance(getApplicationContext());

        proj =  findViewById(R.id.project_spinner);
        String ProjName = proj.getSelectedItem().toString();

        emp =  findViewById(R.id.employee_spinner);
        String EmpName = emp.getSelectedItem().toString();

        EditText Hours= (EditText)findViewById(R.id.hours);
        String desc = Hours.getText().toString();

        EditText Date= (EditText)findViewById(R.id.date_of_work);
        String date = Date.getText().toString();

        EditText Details= (EditText)findViewById(R.id.editText3);
        String details = Details.getText().toString();


        TimeDao3.insertTime(new RecordTime(ProjName,EmpName,date,desc,details));
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        Toast.makeText(this, "Scheduling Item Created" , Toast.LENGTH_LONG).show();


    }








}
