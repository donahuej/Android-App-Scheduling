package com.example.staffingmanager.database;

import com.example.staffingmanager.Employee;

/**
 * Created by danazh on 4/18/18.
 */

public final class EmployeeDBContract {
    public static final String DBName = "employeelist.db";
    public static final int DB_VERSION = 1;

    public static final class EmployeeContract{
        public static final String TABLE_NAME = "employees";
        public static final String COLUMN_Employee_ID = "employee_id";
        public static final String COLUMN_First_Name= "first_name";
        public static final String COLUMN_Last_Name = "last_name";
        public static final String COLUMN_EMAIL = "email";
    }

    public static final String CREATE_PROJECT_TABLE = "CREATE TABLE " +
            EmployeeDBContract.EmployeeContract.TABLE_NAME +
            "(" +
            EmployeeContract.COLUMN_Employee_ID+
            " INTEGER PRIMARY KEY AUTOINCREMENT," +
            EmployeeContract.COLUMN_First_Name +
            " TEXT," +
            EmployeeContract.COLUMN_Last_Name +
            " TEXT," +
            EmployeeContract.COLUMN_EMAIL +

            " TEXT);";

    public static final String DROP_PROJECT_TABLE = "DROP TABLE IF EXISTS "
            + EmployeeDBContract.EmployeeContract.TABLE_NAME;
}
