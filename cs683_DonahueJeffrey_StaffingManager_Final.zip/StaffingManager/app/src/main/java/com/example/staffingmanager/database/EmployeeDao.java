package com.example.staffingmanager.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.staffingmanager.Employee;
import com.example.staffingmanager.Project;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by danazh on 4/18/18.
 */

public class EmployeeDao {
    public static EmployeeDao instance;

    public EmployeeDBHelper EmployeeDBHelper;
    public SQLiteDatabase mReadableDB, mWritableDB;


    public EmployeeDao(Context context){
        EmployeeDBHelper = new EmployeeDBHelper(context);
    }

    public void openDb(){
        mReadableDB = EmployeeDBHelper.getReadableDatabase();
        mWritableDB = EmployeeDBHelper.getWritableDatabase();
    }

    public void closeDB(){
        mReadableDB.close();
        mWritableDB.close();
    }

    public static EmployeeDao getInstance(Context context){
        if (instance == null)
            instance = new EmployeeDao(context);
        return instance;
    }

    public long insertEmployee(Employee employee) {

        ContentValues projectValue = new ContentValues();
        projectValue.put(EmployeeDBContract.EmployeeContract.COLUMN_First_Name,
                employee.getFirstName());
        projectValue.put(EmployeeDBContract.EmployeeContract.COLUMN_Last_Name,
                employee.getLastName());
        projectValue.put(EmployeeDBContract.EmployeeContract.COLUMN_EMAIL,
                employee.getEmail());
        return mWritableDB.insert(EmployeeDBContract.EmployeeContract.TABLE_NAME,
                null, projectValue);
    }

    public long delectEmployeeById(int employeeId) {
        String selection = EmployeeDBContract.EmployeeContract.COLUMN_Employee_ID + "=?";
        String[] selectionArgs = {employeeId+""};

        return mWritableDB.delete(EmployeeDBContract.EmployeeContract.TABLE_NAME ,
                selection,selectionArgs);

    }


    public List<Employee> getAllEmployees() {

            String[] projection = {EmployeeDBContract.EmployeeContract.COLUMN_First_Name,
                    EmployeeDBContract.EmployeeContract.COLUMN_Last_Name,
                    EmployeeDBContract.EmployeeContract.COLUMN_EMAIL};

            Cursor cursor = mReadableDB.query(EmployeeDBContract.EmployeeContract.TABLE_NAME,
                    projection,
                    null, null, null, null,null);

            List<Employee> employees = new ArrayList<Employee>();

            while(cursor.moveToNext()) {
                int projectId = cursor.getInt(cursor.getColumnIndex(
                        EmployeeDBContract.EmployeeContract.COLUMN_Employee_ID));
                String projectName = cursor.getString(cursor.getColumnIndex(
                        EmployeeDBContract.EmployeeContract.COLUMN_First_Name));
                String projectDesc = cursor.getString(cursor.getColumnIndex(
                        EmployeeDBContract.EmployeeContract.COLUMN_Last_Name));
                String projectMan = cursor.getString(cursor.getColumnIndex(
                        EmployeeDBContract.EmployeeContract.COLUMN_EMAIL));

                employees.add(new Employee(projectName,projectDesc, projectMan));
            }

            cursor.close();

            return employees;
    }

    public List<String> getEmployees() {

        String[] projection = {EmployeeDBContract.EmployeeContract.COLUMN_First_Name,
                EmployeeDBContract.EmployeeContract.COLUMN_Last_Name,
                EmployeeDBContract.EmployeeContract.COLUMN_EMAIL};

        Cursor cursor = mReadableDB.query(EmployeeDBContract.EmployeeContract.TABLE_NAME,
                projection,
                null, null, null, null,null);

        List<String> employees = new ArrayList<String>();

        while(cursor.moveToNext()) {
            //int projectId = cursor.getInt(cursor.getColumnIndex(
                    //EmployeeDBContract.EmployeeContract.COLUMN_Employee_ID));
            String employeeFirst = cursor.getString(cursor.getColumnIndex(
                    EmployeeDBContract.EmployeeContract.COLUMN_First_Name));
            String employeeLast = cursor.getString(cursor.getColumnIndex(
                    EmployeeDBContract.EmployeeContract.COLUMN_Last_Name));
            //String projectMan = cursor.getString(cursor.getColumnIndex(
                    //EmployeeDBContract.EmployeeContract.COLUMN_EMAIL));

            employees.add(employeeFirst + " " + employeeLast);
        }

        cursor.close();

        return employees;
    }



/*
    public Project getProjectById(int projectId) {

        String[] projection = {ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID,
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME,
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC,
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER};

        String selection = ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID + "=?";
        String[] selectionArgs = {Integer.toString(projectId)};

        Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                projection, selection, selectionArgs, null, null,null);

        cursor.moveToFirst();

        String projectName = cursor.getString(cursor.getColumnIndex(
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME));
        String projectDesc = cursor.getString(cursor.getColumnIndex(
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC));
        String projectMan = cursor.getString(cursor.getColumnIndex(
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER));

        Project project = new Project(projectName,projectDesc, projectMan);
        cursor.close();

        return project;
    }


*/

}
