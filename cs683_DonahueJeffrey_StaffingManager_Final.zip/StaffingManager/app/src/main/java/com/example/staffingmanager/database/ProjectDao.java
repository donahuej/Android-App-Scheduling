package com.example.staffingmanager.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.staffingmanager.Project;

import java.util.ArrayList;
import java.util.List;

import com.example.staffingmanager.Project;

/**
 * Created by danazh on 4/18/18.
 */

public class ProjectDao {
    public static ProjectDao instance;

    public ProjectPortalDBHelper projectPortalDBHelper;
    public SQLiteDatabase mReadableDB, mWritableDB;


    public ProjectDao(Context context){
        projectPortalDBHelper = new ProjectPortalDBHelper(context);
    }

    public void openDb(){
        mReadableDB = projectPortalDBHelper.getReadableDatabase();
        mWritableDB = projectPortalDBHelper.getWritableDatabase();
    }

    public void closeDB(){
        mReadableDB.close();
        mWritableDB.close();
    }

    public static ProjectDao getInstance(Context context){
        if (instance == null)
            instance = new ProjectDao(context);
        return instance;
    }

    public long insertProject(Project project) {

        ContentValues projectValue = new ContentValues();
        projectValue.put(ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME,
                project.getProjName());
        projectValue.put(ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC,
                project.getProjDesc());
        projectValue.put(ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER,
                project.getProjManager());
        return mWritableDB.insert(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                null, projectValue);
    }

    public long delectProjectById(int projectId) {
        String selection = ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID + "=?";
        String[] selectionArgs = {projectId+""};

        return mWritableDB.delete(ProjectPortalDBContract.ProjectContract.TABLE_NAME ,
                selection,selectionArgs);

    }


    public List<Project> getAllProject() {

            String[] projection = {ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID,
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME,
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC,
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER};

            Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                    projection,
                    null, null, null, null,null);

            List<Project> projects = new ArrayList<Project>();

            while(cursor.moveToNext()) {
                int projectId = cursor.getInt(cursor.getColumnIndex(
                        ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID));
                String projectName = cursor.getString(cursor.getColumnIndex(
                        ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME));
                String projectDesc = cursor.getString(cursor.getColumnIndex(
                        ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC));
                String projectMan = cursor.getString(cursor.getColumnIndex(
                        ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER));

                projects.add(new Project(projectName,projectDesc, projectMan));
            }

            cursor.close();

            return projects;
    }

    public List<String> getAllProjectNames() {

        String[] projection = {ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME};

        Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                projection,
                null, null, null, null,null);

        List<String> projects = new ArrayList<String>();


        while(cursor.moveToNext()) {
            int projectId = cursor.getInt(cursor.getColumnIndex(
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID));
            String projectName = cursor.getString(cursor.getColumnIndex(
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME));
            String projectDesc = cursor.getString(cursor.getColumnIndex(
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC));
            String projectMan = cursor.getString(cursor.getColumnIndex(
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER));

            projects.add(projectName);

        }

        cursor.close();

        return projects;
    }


    public Project getProjectById(int projectId) {

        String[] projection = {ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID,
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME,
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC,
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER};

        String selection = ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID + "=?";
        String[] selectionArgs = {Integer.toString(projectId)};

        Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                projection, selection, selectionArgs, null, null,null);

        cursor.moveToFirst();

        String projectName = cursor.getString(cursor.getColumnIndex(
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME));
        String projectDesc = cursor.getString(cursor.getColumnIndex(
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC));
        String projectMan = cursor.getString(cursor.getColumnIndex(
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER));

        Project project = new Project(projectName,projectDesc, projectMan);
        cursor.close();

        return project;
    }




}
