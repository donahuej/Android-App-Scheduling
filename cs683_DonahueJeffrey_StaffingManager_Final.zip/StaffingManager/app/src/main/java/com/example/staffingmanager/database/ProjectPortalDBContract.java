package com.example.staffingmanager.database;

/**
 * Created by danazh on 4/18/18.
 */

public final class ProjectPortalDBContract {
    public static final String DBName = "projectlist.db";
    public static final int DB_VERSION = 1;

    public static final class ProjectContract{
        public static final String TABLE_NAME = "projects";
        public static final String COLUMN_PROJECT_ID = "project_id";
        public static final String COLUMN_PROJECT_NAME = "project_name";
        public static final String COLUMN_PROJECT_DESC = "project_desc";
        public static final String COLUMN_PROJECT_MANAGER = "project_Manager";
    }

    public static final String CREATE_PROJECT_TABLE = "CREATE TABLE " +
            ProjectPortalDBContract.ProjectContract.TABLE_NAME +
            "(" +
            ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID+
            " INTEGER PRIMARY KEY AUTOINCREMENT," +
            ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME +
            " TEXT," +
            ProjectContract.COLUMN_PROJECT_DESC +
            " TEXT," +
            ProjectContract.COLUMN_PROJECT_MANAGER +

            " TEXT);";

    public static final String DROP_PROJECT_TABLE = "DROP TABLE IF EXISTS "
            + ProjectPortalDBContract.ProjectContract.TABLE_NAME;
}
