package com.example.staffingmanager.database;

/**
 * Created by danazh on 4/18/18.
 */

public final class TimeDBContract {
    public static final String DBName = "timelist.db";
    public static final int DB_VERSION = 1;

    public static final class ProjectContract{
        public static final String TABLE_NAME = "projects";
        public static final String COLUMN_TIME_ID = "project_id";
        public static final String COLUMN_PROJECT_NAME = "project_name";
        public static final String COLUMN_EMPLOYEE_NAME = "employee_name";
        public static final String COLUMN_DATE = "date";
        public static final String COLUMN_HOURS = "project_hours";
        public static final String COLUMN_DETAILS= "project_detaila";

    }

    public static final String CREATE_PROJECT_TABLE = "CREATE TABLE " +
            TimeDBContract.ProjectContract.TABLE_NAME +
            "(" +
            TimeDBContract.ProjectContract.COLUMN_TIME_ID+
            " INTEGER PRIMARY KEY AUTOINCREMENT," +
            TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME +
            " TEXT," +
            TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME +
            " TEXT," +
            TimeDBContract.ProjectContract.COLUMN_DATE +
            " TEXT," +
            TimeDBContract.ProjectContract.COLUMN_HOURS +
            " TEXT," +
            TimeDBContract.ProjectContract.COLUMN_DETAILS +


            " TEXT);";

    public static final String DROP_PROJECT_TABLE = "DROP TABLE IF EXISTS "
            + TimeDBContract.ProjectContract.TABLE_NAME;
}
