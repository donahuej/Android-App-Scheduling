package com.example.staffingmanager.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class TimeDBHelper extends SQLiteOpenHelper {
    SQLiteDatabase sqLiteDatabase;

    public TimeDBHelper(Context context) {
        super(context,TimeDBContract.DBName, null, TimeDBContract.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(TimeDBContract.CREATE_PROJECT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(TimeDBContract.DROP_PROJECT_TABLE);
        onCreate(sqLiteDatabase);
    }

}
