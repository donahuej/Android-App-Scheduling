package com.example.staffingmanager.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.staffingmanager.Project;
import com.example.staffingmanager.RecordTime;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by danazh on 4/18/18.
 */

public class TimeDao {
    public static TimeDao instance;

    public TimeDBHelper timeDBHelper;
    public SQLiteDatabase mReadableDB, mWritableDB;


    public TimeDao(Context context){
        timeDBHelper = new TimeDBHelper(context);
    }

    public void openDb(){
        mReadableDB = timeDBHelper.getReadableDatabase();
        mWritableDB = timeDBHelper.getWritableDatabase();
    }

    public void closeDB(){
        mReadableDB.close();
        mWritableDB.close();
    }

    public static TimeDao getInstance(Context context){
        if (instance == null)
            instance = new TimeDao(context);
        return instance;
    }

    public long insertTime(RecordTime RecordTime) {

        ContentValues projectValue = new ContentValues();
        projectValue.put(TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME,
                RecordTime.getProjName());
        projectValue.put(TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME,
                RecordTime.getEmployeeName());
        projectValue.put(TimeDBContract.ProjectContract.COLUMN_DATE,
                RecordTime.getDate());
        projectValue.put(TimeDBContract.ProjectContract.COLUMN_HOURS,
                RecordTime.getHours());
        projectValue.put(TimeDBContract.ProjectContract.COLUMN_DETAILS,
                RecordTime.getDetails());
        return mWritableDB.insert(TimeDBContract.ProjectContract.TABLE_NAME,
                null, projectValue);
    }
/*
    public long delectProjectById(int projectId) {
        String selection = ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID + "=?";
        String[] selectionArgs = {projectId+""};

        return mWritableDB.delete(ProjectPortalDBContract.ProjectContract.TABLE_NAME ,
                selection,selectionArgs);

    }

*/
    public List<RecordTime> getAllProject() {

            String[] projection = {TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME,
                    TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME,
                    TimeDBContract.ProjectContract.COLUMN_DATE,
                    TimeDBContract.ProjectContract.COLUMN_HOURS,
                    TimeDBContract.ProjectContract.COLUMN_DETAILS};

            Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                    projection,
                    null, null, null, null,null);

            List<RecordTime> projects = new ArrayList<RecordTime>();

            while(cursor.moveToNext()) {
                String projecthours = cursor.getString(cursor.getColumnIndex(
                        TimeDBContract.ProjectContract.COLUMN_HOURS));
                String projectName = cursor.getString(cursor.getColumnIndex(
                        TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME));
                String EmpName = cursor.getString(cursor.getColumnIndex(
                        TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME));
                String projectDate = cursor.getString(cursor.getColumnIndex(
                        TimeDBContract.ProjectContract.COLUMN_DATE));
                String projectDesc = cursor.getString(cursor.getColumnIndex(
                        TimeDBContract.ProjectContract.COLUMN_DETAILS));


                projects.add(new RecordTime(projectName,EmpName,projectDate,projecthours,projectDesc));
            }

            cursor.close();

            return projects;
    }

    public List<RecordTime> getAllProjectbyProject(String project) {

        String[] projection = {TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME,
                TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME,
                TimeDBContract.ProjectContract.COLUMN_DATE,
                TimeDBContract.ProjectContract.COLUMN_HOURS,
                TimeDBContract.ProjectContract.COLUMN_DETAILS};

        Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                projection,
                TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME + "=?", new String[] {project}, null, null,null);

        List<RecordTime> projects = new ArrayList<RecordTime>();

        while(cursor.moveToNext()) {
            String projecthours = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_HOURS));
            String projectName = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME));
            String EmpName = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME));
            String projectDate = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_DATE));
            String projectDesc = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_DETAILS));


            projects.add(new RecordTime(projectName,EmpName,projectDate,projecthours,projectDesc));
        }

        cursor.close();

        return projects;
    }

    public List<RecordTime> getAllProjectbyEmployee(String employee) {

        String[] projection = {TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME,
                TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME,
                TimeDBContract.ProjectContract.COLUMN_DATE,
                TimeDBContract.ProjectContract.COLUMN_HOURS,
                TimeDBContract.ProjectContract.COLUMN_DETAILS};

        Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                projection,
                TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME + "=?", new String[] {employee}, null, null,null);

        List<RecordTime> projects = new ArrayList<RecordTime>();

        while(cursor.moveToNext()) {
            String projecthours = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_HOURS));
            String projectName = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME));
            String EmpName = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME));
            String projectDate = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_DATE));
            String projectDesc = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_DETAILS));


            projects.add(new RecordTime(projectName,EmpName,projectDate,projecthours,projectDesc));
        }

        cursor.close();

        return projects;
    }

    public List<String> getAllProjectNames() {

        String[] projection = {TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME};

        Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                projection,
                null, null, TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME, null,null);

        List<String> projects = new ArrayList<String>();

        while(cursor.moveToNext()) {
            String projectName = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_PROJECT_NAME));



            projects.add(projectName);
        }

        cursor.close();

        return projects;
    }



    public List<String> getAllEmployeeNames() {

        String[] projection = {TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME};

        Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                projection,
                null, null, TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME, null,null);

        List<String> projects = new ArrayList<String>();

        while(cursor.moveToNext()) {
            String projectName = cursor.getString(cursor.getColumnIndex(
                    TimeDBContract.ProjectContract.COLUMN_EMPLOYEE_NAME));



            projects.add(projectName);
        }

        cursor.close();

        return projects;
    }
/*
    public String[] getAllProjectNames() {

        String[] projection = {ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME};

        Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                projection,
                null, null, null, null,null);

        String[] projects = new String[100];
        int i = 0;


        while(cursor.moveToNext()) {
            int projectId = cursor.getInt(cursor.getColumnIndex(
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID));
            String projectName = cursor.getString(cursor.getColumnIndex(
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME));
            String projectDesc = cursor.getString(cursor.getColumnIndex(
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC));
            String projectMan = cursor.getString(cursor.getColumnIndex(
                    ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER));

            projects[i] = projectName;
            i = i+1;

        }

        cursor.close();

        return projects;
    }


    public Project getProjectById(int projectId) {

        String[] projection = {ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID,
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME,
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC,
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER};

        String selection = ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_ID + "=?";
        String[] selectionArgs = {Integer.toString(projectId)};

        Cursor cursor = mReadableDB.query(ProjectPortalDBContract.ProjectContract.TABLE_NAME,
                projection, selection, selectionArgs, null, null,null);

        cursor.moveToFirst();

        String projectName = cursor.getString(cursor.getColumnIndex(
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_NAME));
        String projectDesc = cursor.getString(cursor.getColumnIndex(
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_DESC));
        String projectMan = cursor.getString(cursor.getColumnIndex(
                ProjectPortalDBContract.ProjectContract.COLUMN_PROJECT_MANAGER));

        Project project = new Project(projectName,projectDesc, projectMan);
        cursor.close();

        return project;
    }



*/
}
